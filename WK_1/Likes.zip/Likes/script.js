let count = 0

function increment() {
    count += 1
    countEl.innerText = count
}

let countEl = document.getElementById("count-el")

console.log(countEl)