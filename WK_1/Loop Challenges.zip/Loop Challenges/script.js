// 1. Print odds 1-20
// var myArray = [];

// for(i=1; i<=20; i+=2) {
//     myArray.push(i)
// }
// console.log(myArray)


// 2. Decreasing Multiples of 3

//     for (let i = 100; i >= 0; i--) {
    
//     if (i % 3 == 0)

//     console.log(i);

// }


// 3. Print the sequence

// const mySequence = [4, 2.5, 1, -0.5, -2, -3.5]

// for (let i = 0; i < 6; i++) {
//     console.log(mySequence[i]);
    
// }


// 4. Sigma
// let sum = 0;

// for (let i = 0; i < 101; i++) {
//     sum += i;
    
// }

// console.log(sum);


// 5. Factorial
// let array = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
//         p = 1,
//         i;

// for (let i = 0; i < array.length; i += 1) {
//     p *= array[i];
// };

// console.log("Product: " + p);



